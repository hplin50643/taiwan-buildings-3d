"""Recolor exact original STL triangles without changing geometry. Python + numpy."""
from pathlib import Path
import struct,hashlib,json,zipfile,xml.etree.ElementTree as E
import numpy as np
A=Path(__file__).resolve().parents[1];R=A.parent
SOURCE_SHA='30769931f58c5095803700b6462694aa6485b42c6979ca540da8d834d3767320'
PALETTE=[('neutral_unconfirmed_frames_envelope_base','#AAA79F'),('documented_glazing_opaque_proxy','#465C61'),('approximate_pale_gray_front_roof_fascia','#C5C6BE')]
def classify(tri):
 t=tri;eps=.002;lo=t.min(axis=1);hi=t.max(axis=1)
 color=np.zeros(len(t),dtype=int);why=np.full(len(t),'neutral_unconfirmed_or_outside_documented_scope',dtype=object)
 for z in [14.1,38.1]:
  height=(lo[:,2]>=z-eps)&(hi[:,2]<=z+18+eps)
  for x in range(-55,60,10):
   mask=np.all(abs(t[:,:,1]+32.2)<eps,axis=1)&(lo[:,0]>=x-4.25-eps)&(hi[:,0]<=x+4.25+eps)&height
   assert mask.sum()==2
   color[mask]=1;why[mask]='documented_front_full_window_back'
  for y in [-26,-15,-4,7]:
   mask=np.all(abs(t[:,:,0]-59.2)<eps,axis=1)&(lo[:,1]>=y-4.7-eps)&(hi[:,1]<=y+4.7+eps)&height
   assert mask.sum()==2
   color[mask]=1;why[mask]='documented_right_front_four_bays_full_window_back'
 assert color.sum()==64

 ids=[2866, 2877];assert not color[ids].any();assert np.all(abs(t[ids,:,1]+43.5)<1e-5)
 color[ids]=2;why[ids]='complete_front_vertical_roof_fascia_pale_gray_family'
 return color,why

def writezip(path,files):
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name,data in files:
   info=zipfile.ZipInfo(name,(2026,10,20,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644<<16;z.writestr(info,data)
def main():
 (A/'qa-fascia-continuation').mkdir(exist_ok=True);(A/'previews').mkdir(exist_ok=True)
 raw=(R/'model.stl').read_bytes();assert hashlib.sha256(raw).hexdigest()==SOURCE_SHA
 n=struct.unpack_from('<I',raw,80)[0];assert len(raw)==84+50*n
 tri=np.array([struct.unpack_from('<9f',raw,96+50*i) for i in range(n)],dtype=np.float64).reshape(n,3,3)
 v,inv=np.unique(tri.reshape(-1,3),axis=0,return_inverse=True);f=inv.reshape(-1,3)
 colors,why=classify(tri);assert set(colors)==set(range(len(PALETTE)))
 # .17g exactly roundtrips every source float32 value as float64.
 ns='http://schemas.microsoft.com/3dmanufacturing/core/2015/02';E.register_namespace('',ns)
 model=E.Element('{'+ns+'}model',{'unit':'millimeter','{http://www.w3.org/XML/1998/namespace}lang':'en-US'});res=E.SubElement(model,'resources');bm=E.SubElement(res,'basematerials',{'id':'20'})
 for name,color in PALETTE:E.SubElement(bm,'base',{'name':name,'displaycolor':color+'FF'})
 obj=E.SubElement(res,'object',{'id':'1','type':'model','pid':'20','pindex':'1','name':'NCCU Lakeside Reading House limited original surface'});mesh=E.SubElement(obj,'mesh');vs=E.SubElement(mesh,'vertices');ts=E.SubElement(mesh,'triangles')
 for p in v:E.SubElement(vs,'vertex',dict(zip('xyz',[format(float(x),'.17g') for x in p])))
 for t,col in zip(f,colors):E.SubElement(ts,'triangle',{'v1':str(t[0]),'v2':str(t[1]),'v3':str(t[2]),'pid':'20','p1':str(col),'p2':str(col),'p3':str(col)})
 E.SubElement(E.SubElement(model,'build'),'item',{'objectid':'1'})
 writezip(A/'nccu-lakeside-appearance.3mf',[
 ('[Content_Types].xml',b'<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/></Types>'),
 ('_rels/.rels',b'<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>'),
 ('3D/3dmodel.model',E.tostring(model,encoding='utf-8',xml_declaration=True))])
 (A/'palette.json').write_text(json.dumps({'materials':[{'id':n,'srgb':c} for n,c in PALETTE],'colors':'Architect-authored 2022/03 publication; photo exposure date unknown; viewed 2026-10-22; uncalibrated opaque glazing proxy, not 2026 condition','scope':'Only 24 front and 8 right-front window backs, 64 complete original triangles. Continuation adds2 complete front vertical roofslab fascia faces only. Other frames, left staircase, right rear bays, rear, roof top/soffit/fold remain neutral.'},ensure_ascii=False,indent=2)+'\n')
 (A/'face-materials.json').write_text(json.dumps({'source_stl_sha256':SOURCE_SHA,'vertices':len(v),'triangles':len(f),'original_triangle_order_unchanged':True,'face_material_indices':colors.tolist(),'face_reasons':why.tolist()},indent=2)+'\n')
 print(json.dumps({'faces':len(f),'vertices':len(v),'materials':dict(zip([x[0] for x in PALETTE],np.bincount(colors).tolist()))}))
if __name__=='__main__':main()
